<?php

	include("inc.inc"); 	
	$result=mysqli_query($conn,"SELECT * FROM $tblname ORDER BY dataID DESC"); //DESC menurun ASC menaik
?>
<html>
	<head>
		<title>Statistik Data Harian Sungai</title>
		<link rel="stylesheet" href="./css/style.css">
		<link rel="stylesheet" href="./css/bootstrap.css">
		<meta http-equiv="refresh" content="30"><!-- refresh every 30 seconds-->
	</head>
	<body>
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<center><h3 style="text-align:right;" class="hijau tebel">STATUS KETINGGIAN AIR SUNGAI DI DAERAH GOMBAK</h3></center>
			</div>
			<div class="col-md-2">
				&nbsp;
			</div>
		</div>
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<center><h5 style="text-align:right;" class="miring">Data Logging dengan Arduino, NodeMCU & Ultrasonic Sensor</h5></center>
				<hr style="margin-top: 0px; margin-bottom:0px">
			</div>
			<div class="col-md-2">
				&nbsp;
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-2 col-md-offset-2">
				<div class="panel panel-primary">
  					<div class="panel-heading">
    					<h3 class="panel-title tengah">Navigasi</h3>
  					</div>
  					<div class="panel-body" style="padding:0px;">
    					<table class="table table-stripped table-hover" >
							<tbody>
								<tr>
									<td><span class="glyphicon glyphicon-home"></span><a href="./error.php" style="text-decoration:none;"> Home</a></td>
								</tr>
								<tr class="info">
									<td><span class="glyphicon glyphicon-th-list" ></span><a href="./index.php" style="text-decoration:none;"> Jadual/Table</a></td>
								</tr>
								<tr>
									<td><span class="glyphicon glyphicon-stats"></span><a href="./error.php" style="text-decoration:none;"> Statistik</td>
								</tr>
							</tbody>
						</table>
  					</div>
				</div>	
			</div>
			<div class="col-md-6">
				<p class="tebel">Tabel Data Suhu:</p>
				<table class="table table-striped table-bordered">
					<thead>
						<td><center><p class="tebel" style="margin-top:0px; margin-bottom:0px;">No</p></center></td>
						<td><center><p class="tebel" style="margin-top:0px; margin-bottom:0px;">Tarikh Log</p></center></td>
						<td><center><p class="tebel" style="margin-top:0px; margin-bottom:0px;">Nama Sungai</p></center></td>
						<td><center><p class="tebel" style="margin-top:0px; margin-bottom:0px;">Level Sungai</p></center></td>
						<td><center><p class="tebel" style="margin-top:0px; margin-bottom:0px;">Status Keadaan</p></center></td>
					</thead>
					<tbody>
						<?php 
		  					if($result!==FALSE){
							    while($row = mysqli_fetch_array($result)) {
									//extract $row;
							        printf("<tr><td> &nbsp;%s </td><td> &nbsp;%s </td><td> &nbsp;%s </td><td> &nbsp;%s&nbsp; </td><td> &nbsp;%s&nbsp; </td></tr>", 
						            //$row["tgl"], $row["temp"], $row["rh"]);
							        $row["dataID"], $row["log"], $row["river_name"], $row["water_level"], $row["river_status"]);

							    }
								//json_encode($data);
							    mysqli_free_result($result);
							    mysqli_close($conn);
							}
      					?>
					</tbody>
				</table>
			</div>
		</div>
	</body>
</html>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
	<script type="text/javascript" src="./js/modules/data.js"></script>
	<script type="text/javascript" src="./js/modules/exporting.js"></script>
	<script type="text/javascript" src="./js/highcharts.js"></script>
	<script type="text/javascript" src="./js/bootstrap.js"></script>