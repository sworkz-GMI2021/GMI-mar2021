<?php
   include("inc.inc");
   	
   //$link=Connection();
   date_default_timezone_set("Asia/Kuala_Lumpur");
   $height=$_GET["dist"];/// get data from NodeMCU & must same with in the NodeMCU port
   $locate=$_GET["loc"];/// get data from NodeMCU & must same with in the NodeMCU port
   
   //Location
   if ($locate == 1)
   {
      $location = "SG PUSU, GOMBAK";
   } else if ($locate ==2)
   {
   	  $location = "SG CHINCHIN, GOMBAK";
   }else{
   	  $location = "RIVER NOT LISTED!";
   }
   echo "<br>Height: ".$height. "cm & Location: ". $location; //flag to check data send form sensor
   
   //THE FORMULA @ CONDITIONS
   //only  2 conditions, 
   if ($height < 5) //if the height between sensor & water surface is less then 5cm-> status = DANGER
   {
      $status = "DANGER";
   } else {
      $status = "SAFE";
   }

   echo "<br>".$status;
   //insert into table level_status_daerah1 (field from mysql) VALUES (data from php & NodeMCU)
	$query = "INSERT INTO $tblname(river_name, water_level, river_status) VALUES ('$location','$height', '$status')"; 
   	
   if  ((is_null($height) or is_null($location)))
   {
      echo "Empty data"; //flag
   }
   else
   {
   	  // if everything is complete, add data from NodeMCU inside the database
      mysqli_query($conn, $query) or die('Failed to update site table. Mysql returned the following:'.mysqli_error());
      echo "<br>Added to DB"; //flag
      
   }
   //header("Location: index.php");
?>
